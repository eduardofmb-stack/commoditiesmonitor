# Coleta de preços do Monitor de Commodities

Baixa todo dia útil, às 06h30 de Brasília, e grava em `data/`:

| Arquivo | Conteúdo | Fonte |
|---|---|---|
| `futuros.csv` | Fechamentos diários, por contrato, de soja e milho (CBOT) e algodão (ICE), até um ano | Yahoo Finance |
| `continuo.csv` | Série contínua do primeiro vencimento, dez anos | Yahoo Finance |
| `dolar_ptax.csv` | Dólar PTAX de venda, dez anos | Banco Central (SGS 1) |
| `cftc.csv` | Posição dos fundos (managed money), cinco anos | CFTC |
| `status.json` | O que funcionou e o que falhou na última execução | |

Não cobre: boi gordo na B3, indicadores Cepea, praças e prêmios de porto. Esses seguem com a rotina do Claude.

## Como instalar (uma vez)

1. Crie uma conta em github.com e um repositório **público** chamado `monitor-commodities`.
2. Envie para ele os três itens desta pasta: `coletar.py`, `LEIA-ME.md` e a pasta `.github`.
3. Na aba **Actions**, abra "Coleta diária de preços" e clique em **Run workflow** para a primeira execução.
4. Confira se apareceu a pasta `data/` e envie ao Claude o endereço do repositório.

O script ainda não foi executado contra as fontes reais: a primeira execução mostra, em `data/status.json`, quais delas respondem.
